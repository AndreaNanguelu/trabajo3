<html lang="es">
<head>
    <title>Ejercicios es PHP</title>
    <link rel="stylesheet" type="text/css" href="css/Style.css">
    <meta charset="utf-8"/>
</head>
<body> 
<h1><center>VARIABLES</center></h1>
    
	    <ul>
    <center><a href="ejercicio1.php">Ejercicio 1</a>
            <a href="ejercicio2.php">Ejercicio 2</a>
            <a href="ejercicio3.php">Ejercicio 3</a>
            <a href="ejercicio4.php">Ejercicio 4</a>
            <a href="ejercicio5.php">Ejercicio 5</a></center>
        </ul>
 <footer>   
<br><p>ANDREA LIZETH NANGUELU ALCOCER</p>
</footer>
</body>
</html>
